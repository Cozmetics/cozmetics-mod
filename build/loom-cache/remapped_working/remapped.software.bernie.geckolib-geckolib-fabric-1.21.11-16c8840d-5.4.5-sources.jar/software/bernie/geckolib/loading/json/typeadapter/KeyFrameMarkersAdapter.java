package software.bernie.geckolib.loading.json.typeadapter;

import com.google.gson.*;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.ApiStatus;
import software.bernie.geckolib.cache.GeckoLibResources;
import software.bernie.geckolib.cache.animation.Animation;
import software.bernie.geckolib.cache.animation.keyframeevent.CustomInstructionKeyframeData;
import software.bernie.geckolib.cache.animation.keyframeevent.ParticleKeyframeData;
import software.bernie.geckolib.cache.animation.keyframeevent.SoundKeyframeData;

import java.lang.reflect.Type;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.util.JsonHelper;

/**
 * {@link Gson} {@link JsonDeserializer} for {@link Animation.KeyframeMarkers}
 */
@ApiStatus.Internal
public final class KeyFrameMarkersAdapter {
	/**
	 * Create a GSON {@link JsonDeserializer} for {@link Animation.KeyframeMarkers}
	 */
	public static JsonDeserializer<Animation.KeyframeMarkers> deserializer() throws JsonParseException {
		return KeyFrameMarkersAdapter::fromJson;
	}

	/**
	 * Deserialize a {@link Animation.KeyframeMarkers} from a {@link JsonElement}.
	 */
	private static Animation.KeyframeMarkers fromJson(JsonElement json, Type type, JsonDeserializationContext context) {
		JsonObject obj = json.getAsJsonObject();
		SoundKeyframeData[] sounds = buildSoundFrameData(obj);
		ParticleKeyframeData[] particles = buildParticleFrameData(obj);
		CustomInstructionKeyframeData[] customInstructions = buildCustomFrameData(obj);

		return new Animation.KeyframeMarkers(sounds, particles, customInstructions);
	}

	private static SoundKeyframeData[] buildSoundFrameData(JsonObject rootObj) {
		JsonObject soundsObj = JsonHelper.getObject(rootObj, "sound_effects", new JsonObject());
        List<SoundKeyframeData> sounds = new ObjectArrayList<>(soundsObj.size());

		for (Map.Entry<String, JsonElement> entry : soundsObj.entrySet()) {
			sounds.add(new SoundKeyframeData(Double.parseDouble(entry.getKey()), JsonHelper.getString(entry.getValue().getAsJsonObject(), "effect")));
		}

        sounds.sort(Comparator.comparing(SoundKeyframeData::getTime));

		return sounds.toArray(new SoundKeyframeData[0]);
	}

	private static ParticleKeyframeData[] buildParticleFrameData(JsonObject rootObj) {
		JsonObject particlesObj = JsonHelper.getObject(rootObj, "particle_effects", new JsonObject());
        List<ParticleKeyframeData> particles = new ObjectArrayList<>(particlesObj.size());

		for (Map.Entry<String, JsonElement> entry : particlesObj.entrySet()) {
			JsonObject obj = entry.getValue().getAsJsonObject();
			String effect = JsonHelper.getString(obj, "effect", "");
			String locator = JsonHelper.getString(obj, "locator", "");
			String script = JsonHelper.getString(obj, "pre_effect_script", "");

			particles.add(new ParticleKeyframeData(Double.parseDouble(entry.getKey()), effect, locator, script));
		}

        particles.sort(Comparator.comparing(ParticleKeyframeData::getTime));

        return particles.toArray(new ParticleKeyframeData[0]);
	}

	private static CustomInstructionKeyframeData[] buildCustomFrameData(JsonObject rootObj) {
		JsonObject customInstructionsObj = JsonHelper.getObject(rootObj, "timeline", new JsonObject());
		List<CustomInstructionKeyframeData> customInstructions = new ObjectArrayList<>(customInstructionsObj.size());

		for (Map.Entry<String, JsonElement> entry : customInstructionsObj.entrySet()) {
			String instructions;

			if (entry.getValue() instanceof JsonArray array) {
				instructions = GeckoLibResources.GSON.fromJson(array, ObjectArrayList.class).toString();
			}
			else if (entry.getValue() instanceof JsonPrimitive primitive) {
				instructions = primitive.getAsString();
			}
            else {
                instructions = "";
            }

			customInstructions.add(new CustomInstructionKeyframeData(Double.parseDouble(entry.getKey()), instructions));
		}

        customInstructions.sort(Comparator.comparing(CustomInstructionKeyframeData::getTime));

		return customInstructions.toArray(new CustomInstructionKeyframeData[0]);
	}
}
