package software.bernie.geckolib.loading.json.typeadapter;

import com.google.gson.*;
import it.unimi.dsi.fastutil.doubles.DoubleObjectPair;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.apache.commons.lang3.math.NumberUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animation.object.EasingType;
import software.bernie.geckolib.animation.object.LoopType;
import software.bernie.geckolib.cache.animation.Animation;
import software.bernie.geckolib.cache.animation.BoneAnimation;
import software.bernie.geckolib.cache.animation.Keyframe;
import software.bernie.geckolib.cache.animation.KeyframeStack;
import software.bernie.geckolib.loading.math.MathParser;
import software.bernie.geckolib.loading.math.MathValue;
import software.bernie.geckolib.loading.math.function.misc.ToRadFunction;
import software.bernie.geckolib.loading.math.value.Constant;
import software.bernie.geckolib.loading.math.value.Negative;
import software.bernie.geckolib.loading.object.BakedAnimations;
import software.bernie.geckolib.object.CompoundException;
import software.bernie.geckolib.util.JsonUtil;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.util.JsonHelper;

/**
 * {@link Gson} {@link JsonDeserializer} for {@link BakedAnimations}.<br>
 * Acts as the deserialization interface for {@code BakedAnimations}
 */
@ApiStatus.Internal
public final class BakedAnimationsAdapter {
	public static @Nullable ConcurrentMap<Double, Constant> COMPRESSION_CACHE = null;

	/**
	 * Create a GSON {@link JsonDeserializer} for {@link BakedAnimations}
	 */
	public static JsonDeserializer<BakedAnimations> deserializer() throws JsonParseException {
		return BakedAnimationsAdapter::fromJson;
	}

	/**
	 * Deserialize a {@link BakedAnimations} from a {@link JsonElement}.
	 */
	public static BakedAnimations fromJson(JsonElement json, Type type, JsonDeserializationContext context) {
		JsonObject obj = json.getAsJsonObject();
		Map<String, Animation> animations = new Object2ObjectOpenHashMap<>(obj.size());

		for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
			try {
				animations.put(entry.getKey(), bakeAnimation(entry.getKey(), entry.getValue().getAsJsonObject(), context));
			}
			catch (Exception ex) {
				if (ex instanceof CompoundException compoundEx) {
					compoundEx.withMessage("Unable to parse animation: " + entry.getKey());
				}
				else {
					GeckoLibConstants.LOGGER.error("Unable to parse animation: {}", entry.getKey());
				}

                //noinspection CallToPrintStackTrace
                ex.printStackTrace();
			}
		}

		return new BakedAnimations(animations);
	}

	private static Animation bakeAnimation(String name, JsonObject animationObj, JsonDeserializationContext context) throws CompoundException {
		double length = animationObj.has("animation_length") ? JsonHelper.getDouble(animationObj, "animation_length") : -1;
		LoopType loopType = LoopType.fromJson(animationObj.get("loop"));
		BoneAnimation[] boneAnimations = bakeBoneAnimations(JsonHelper.getObject(animationObj, "bones", new JsonObject()));
		Animation.KeyframeMarkers keyframes = context.deserialize(animationObj, Animation.KeyframeMarkers.class);

		if (length == -1)
			length = calculateAnimationLength(boneAnimations);

		return Animation.create(name, length, loopType, boneAnimations, keyframes);
	}

	private static BoneAnimation[] bakeBoneAnimations(JsonObject bonesObj) throws CompoundException {
		BoneAnimation[] animations = new BoneAnimation[bonesObj.size()];
		int index = 0;

		for (Map.Entry<String, JsonElement> entry : bonesObj.entrySet()) {
			JsonObject entryObj = entry.getValue().getAsJsonObject();
			KeyframeStack scaleFrames = buildKeyframeStack(getKeyframes(entryObj.get("scale")), false);
			KeyframeStack positionFrames = buildKeyframeStack(getKeyframes(entryObj.get("position")), false);
			KeyframeStack rotationFrames = buildKeyframeStack(getKeyframes(entryObj.get("rotation")), true);

			animations[index] = new BoneAnimation(entry.getKey(), rotationFrames, positionFrames, scaleFrames);
			index++;
		}

		return animations;
	}

	private static List<DoubleObjectPair<JsonElement>> getKeyframes(@Nullable JsonElement element) {
		if (element == null)
			return List.of();

		if (element instanceof JsonPrimitive primitive) {
			JsonArray array = new JsonArray(3);

			array.add(primitive);
			array.add(primitive);
			array.add(primitive);

			element = array;
		}

		if (element instanceof JsonArray array)
			return ObjectArrayList.of(DoubleObjectPair.of(0, array));

		if (element instanceof JsonObject obj) {
			if (obj.has("vector"))
				return ObjectArrayList.of(DoubleObjectPair.of(0, obj));

			List<DoubleObjectPair<JsonElement>> list = new ObjectArrayList<>();

			for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
				double timestamp = readTimestamp(entry.getKey());

				if (timestamp == 0 && !list.isEmpty())
					throw new JsonParseException("Invalid keyframe data - multiple starting keyframes?" + entry.getKey());

				if (entry.getValue() instanceof JsonObject entryObj && !entryObj.has("vector")) {
					addBedrockKeyframes(timestamp, entryObj, list);

					continue;
				}

				list.add(DoubleObjectPair.of(timestamp, entry.getValue()));
			}

			return list;
		}

		throw new JsonParseException("Invalid object type provided to getTripletObj, got: " + element);
	}

    // Blockbench is just getting silly now
    private static JsonArray extractBedrockKeyframe(JsonElement keyframe) {
        if (keyframe.isJsonArray())
            return keyframe.getAsJsonArray();

        if (!keyframe.isJsonObject())
            throw new JsonParseException("Invalid keyframe data - expected array or object, found " + keyframe);

        JsonObject keyframeObj = keyframe.getAsJsonObject();

        if (keyframeObj.has("vector"))
            return keyframeObj.get("vector").getAsJsonArray();

        if (keyframeObj.has("pre"))
            return keyframeObj.get("pre").getAsJsonArray();

        return keyframeObj.get("post").getAsJsonArray();
    }

	private static void addBedrockKeyframes(double timestamp, JsonObject keyframe, List<DoubleObjectPair<JsonElement>> keyframes) {
		boolean addedFrame = false;

		if (keyframe.has("pre")) {
			addedFrame = true;

            keyframes.add(DoubleObjectPair.of(timestamp == 0 ? timestamp : timestamp - 0.001d, extractBedrockKeyframe(keyframe.get("pre"))));
		}

		if (keyframe.has("post")) {
            JsonArray values = extractBedrockKeyframe(keyframe.get("post"));

			if (keyframe.has("lerp_mode")) {
				JsonObject keyframeObj = new JsonObject();

				keyframeObj.add("vector", values);
				keyframeObj.add("easing", keyframe.get("lerp_mode"));

				keyframes.add(DoubleObjectPair.of(timestamp, keyframeObj));
			}
			else {
				keyframes.add(DoubleObjectPair.of(timestamp, values));
			}

			return;
		}

		if (!addedFrame)
			throw new JsonParseException("Invalid keyframe data - expected array, found " + keyframe);
	}

	private static KeyframeStack buildKeyframeStack(List<DoubleObjectPair<JsonElement>> entries, boolean isForRotation) throws CompoundException {
		if (entries.isEmpty())
			return KeyframeStack.EMPTY;

		List<Keyframe> xFrames = new ObjectArrayList<>();
		List<Keyframe> yFrames = new ObjectArrayList<>();
		List<Keyframe> zFrames = new ObjectArrayList<>();

		MathValue xPrev = null;
		MathValue yPrev = null;
		MathValue zPrev = null;
		DoubleObjectPair<JsonElement> prevEntry = null;

		for (DoubleObjectPair<JsonElement> entry : entries) {
			JsonElement element = entry.right();

			double prevTime = prevEntry != null ? prevEntry.leftDouble() : 0;
			double curTime = entry.leftDouble();
			double timeDelta = curTime - prevTime;

			JsonArray keyFrameVector = element instanceof JsonArray array ? array : JsonHelper.getArray(element.getAsJsonObject(), "vector");
			MathValue rawXValue = MathParser.parseJson(keyFrameVector.get(0));
			MathValue rawYValue = MathParser.parseJson(keyFrameVector.get(1));
			MathValue rawZValue = MathParser.parseJson(keyFrameVector.get(2));
			MathValue xValue = compressMathValue(isForRotation ? new Negative(new ToRadFunction(rawXValue)) : rawXValue);
			MathValue yValue = compressMathValue(isForRotation ? new Negative(new ToRadFunction(rawYValue)) : rawYValue);
			MathValue zValue = compressMathValue(isForRotation ? new ToRadFunction(rawZValue) : rawZValue);

			JsonObject entryObj = element instanceof JsonObject obj ? obj : null;
			EasingType easingType = entryObj != null && entryObj.has("easing") ? EasingType.fromJson(entryObj.get("easing")) : EasingType.LINEAR;
			List<MathValue> easingArgs = entryObj != null && entryObj.has("easingArgs") ?
										 JsonUtil.jsonArrayToList(JsonHelper.getArray(entryObj, "easingArgs"), ele -> new Constant(ele.getAsDouble())) :
										 new ObjectArrayList<>();

			xFrames.add(new Keyframe(curTime, timeDelta, prevEntry == null ? xValue : xPrev, xValue, easingType, easingArgs));
			yFrames.add(new Keyframe(curTime, timeDelta, prevEntry == null ? yValue : yPrev, yValue, easingType, easingArgs));
			zFrames.add(new Keyframe(curTime, timeDelta, prevEntry == null ? zValue : zPrev, zValue, easingType, easingArgs));

			xPrev = xValue;
			yPrev = yValue;
			zPrev = zValue;
			prevEntry = entry;
		}

		return new KeyframeStack(addSplineArgs(xFrames), addSplineArgs(yFrames), addSplineArgs(zFrames));
	}

	private static List<Keyframe> addSplineArgs(List<Keyframe> frames) {
		if (frames.size() == 1) {
			Keyframe frame = frames.getFirst();

			if (frame.easingType() != EasingType.LINEAR) {
				frames.set(0, new Keyframe(frame.startTime(), frame.length(), frame.startValue(), frame.endValue()));

				return frames;
			}
		}

		for (int i = 0; i < frames.size(); i++) {
			Keyframe frame = frames.get(i);

			if (frame.easingType() == EasingType.CATMULLROM) {
				frames.set(i, new Keyframe(frame.startTime(), frame.length(), frame.startValue(), frame.endValue(), frame.easingType(), ObjectArrayList.of(
						i == 0 ? frame.startValue() : frames.get(i - 1).endValue(),
						i + 1 >= frames.size() ? frame.endValue() : frames.get(i + 1).endValue()
				)));
			}
		}

		return frames;
	}

	private static MathValue compressMathValue(MathValue input) {
		if (COMPRESSION_CACHE == null || input.isMutable())
			return input;

        //noinspection DataFlowIssue
        return COMPRESSION_CACHE.computeIfAbsent(input.get(null), Constant::new);
	}

	private static double calculateAnimationLength(BoneAnimation[] boneAnimations) {
		double length = 0;

		for (BoneAnimation animation : boneAnimations) {
			length = Math.max(length, animation.rotationKeyFrames().getTotalKeyframeTime());
			length = Math.max(length, animation.positionKeyFrames().getTotalKeyframeTime());
			length = Math.max(length, animation.scaleKeyFrames().getTotalKeyframeTime());
		}

		return length == 0 ? Double.MAX_VALUE : length;
	}

	private static double readTimestamp(String timestamp) {
		return NumberUtils.isCreatable(timestamp) ? Double.parseDouble(timestamp) : 0;
	}
}