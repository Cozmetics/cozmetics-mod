package io.github.itsarcn.cozmetics.client;

import io.github.itsarcn.cozmetics.Cozmetics;
import io.github.itsarcn.cozmetics.client.render.PetFeatureRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.class_1007;
import net.minecraft.class_1299;

public class CozmeticsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		Cozmetics.LOGGER.info("Initializing Cozmetics client...");

		LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) -> {
			if (entityType == class_1299.field_6097 && entityRenderer instanceof class_1007 playerRenderer) {
				registrationHelper.register(new PetFeatureRenderer(playerRenderer));
			}
		});
	}
}