package io.github.itsarcn.cozmetics.client.render;

import io.github.itsarcn.cozmetics.client.cosmetic.ClientCosmeticManager;
import io.github.itsarcn.cozmetics.client.cosmetic.pet.AngelPetRenderer;
import io.github.itsarcn.cozmetics.cosmetic.Cosmetic;
import io.github.itsarcn.cozmetics.cosmetic.CosmeticCategory;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_591;

/**
 * FeatureRenderer that renders equipped pet cosmetics on players.
 */
public class PetFeatureRenderer extends class_3887<class_10055, class_591> {
	private final AngelPetRenderer petRenderer = new AngelPetRenderer();

	public PetFeatureRenderer(class_3883<class_10055, class_591> context) {
		super(context);
	}

	@Override
	public void render(class_4587 matrices, class_11659 queue, int light, class_10055 state, float limbAngle, float limbDistance) {
		if (state.field_53333 || state.field_53542) {
			return;
		}

		Cosmetic equippedPet = ClientCosmeticManager.getInstance().getEquipped(CosmeticCategory.PET);
		if (equippedPet == null) {
			return;
		}

		petRenderer.renderPet(matrices, queue, null, light, state);
	}
}
