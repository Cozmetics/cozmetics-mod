package io.github.itsarcn.cozmetics.client.cosmetic.pet;

import io.github.itsarcn.cozmetics.cosmetic.AngelPetCosmetic;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.base.GeoRenderState;

/**
 * GeckoLib GeoModel for the Angel Pet.
 */
public class AngelPetModel extends GeoModel<AngelPetAnimatable> {
	@Override
	public class_2960 getModelResource(GeoRenderState renderState) {
		return AngelPetCosmetic.MODEL_PATH;
	}

	@Override
	public class_2960 getTextureResource(GeoRenderState renderState) {
		return AngelPetCosmetic.TEXTURE_PATH;
	}

	@Override
	public class_2960 getAnimationResource(AngelPetAnimatable animatable) {
		return AngelPetCosmetic.ANIMATION_PATH;
	}
}
