package io.github.itsarcn.cozmetics.client.cosmetic.pet;

import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.renderer.GeoObjectRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;
import software.bernie.geckolib.renderer.base.RenderPassInfo;

/**
 * GeoObjectRenderer for the Angel Pet attached to the player.
 */
public class AngelPetRenderer extends GeoObjectRenderer<AngelPetAnimatable, class_10055, GeoRenderState> {
	private final AngelPetAnimatable animatable = new AngelPetAnimatable();

	public AngelPetRenderer() {
		super(new AngelPetModel());
	}

	@Override
	public long getInstanceId(AngelPetAnimatable animatable, @Nullable class_10055 relatedObject) {
		return relatedObject != null ? (long) relatedObject.field_53528 : 0L;
	}

	@Override
	public void adjustRenderPose(RenderPassInfo<GeoRenderState> renderPassInfo) {
		// Minecraft feature rendering is in the entity space where player feet are at Y=1.5 and inverted.
		// The Blockbench model's anchor_body is pivoted at [0, 24, 0] (which is Y=1.5 in Minecraft blocks).
		// We translate to the player base and invert Y/X to match Blockbench Bedrock coordinate orientation.
		renderPassInfo.poseStack().method_46416(0.0F, 1.5F, 0.0F);
		renderPassInfo.poseStack().method_22905(-1.0F, -1.0F, 1.0F);
	}

	public void renderPet(class_4587 matrices, class_11659 queue, @Nullable class_12075 camera, int light, class_10055 playerState) {
		performRenderPass(this.animatable, playerState, matrices, queue, camera, light, 0);
	}
}
