package io.github.itsarcn.cozmetics.cosmetic;

import io.github.itsarcn.cozmetics.Cozmetics;
import net.minecraft.class_2960;

/**
 * Definition of the first working cosmetic: Angel Pet.
 */
public class AngelPetCosmetic implements Cosmetic {
	public static final class_2960 ID = Cozmetics.id("angel_pet");
	public static final class_2960 MODEL_PATH = Cozmetics.id("cosmetics/pets/angel_pet");
	public static final class_2960 TEXTURE_PATH = Cozmetics.id("textures/cosmetics/pets/angel_pet.png");
	public static final class_2960 ANIMATION_PATH = Cozmetics.id("cosmetics/pets/angel_pet");

	@Override
	public class_2960 getId() {
		return ID;
	}

	@Override
	public CosmeticCategory getCategory() {
		return CosmeticCategory.PET;
	}

	@Override
	public String getName() {
		return "Angel Pet";
	}

	@Override
	public boolean isAnimated() {
		return true;
	}

	@Override
	public class_2960 getModelPath() {
		return MODEL_PATH;
	}

	@Override
	public class_2960 getTexturePath() {
		return TEXTURE_PATH;
	}

	@Override
	public class_2960 getAnimationPath() {
		return ANIMATION_PATH;
	}
}
