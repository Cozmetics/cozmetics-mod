package io.github.itsarcn.cozmetics.cosmetic;

import net.minecraft.class_2960;

/**
 * Common representation of a cosmetic item/model.
 * Prepared for static models, animated GeckoLib models, and future cosmetic types.
 */
public interface Cosmetic {
	/**
	 * Unique identifier for this cosmetic (e.g. cozmetics:angel_pet).
	 */
	class_2960 getId();

	/**
	 * Category this cosmetic belongs to.
	 */
	CosmeticCategory getCategory();

	/**
	 * Human-readable display name.
	 */
	String getName();

	/**
	 * Whether this cosmetic uses an animated model (e.g. GeckoLib).
	 */
	boolean isAnimated();

	/**
	 * Subpath/identifier for the model file.
	 */
	class_2960 getModelPath();

	/**
	 * Identifier for the texture resource.
	 */
	class_2960 getTexturePath();

	/**
	 * Subpath/identifier for the animation file (if animated).
	 */
	class_2960 getAnimationPath();
}
